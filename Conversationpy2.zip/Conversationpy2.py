#Python ask user for input
userName = raw_input("Hello my name is Cortenex. \n What is your name? ") 

#Python use that input
print'Hello', userName,"\n  How has your day been so far?"

#Python Ask about day
raw_input()
print"Thats good I hope it gets even better", userName, "\n Let's play a game ? "
userName2 = raw_input()

print"We are going to play talk to me."
raw_input()

#Game of Talk to me
print"Why am I here?"

userName3 = raw_input()

import time
time.sleep(2) #delays for 2 seconds

print"I like your response", userName, "\n But the only one to know the true answer is my creator."

#End of Game With wait of 1 second

import time
time.sleep(1) #delays for 1 second

userName4 = raw_input("I grow tired of this game. \n Can I go?  ")

#The Final Response

print"I am sorry but I do not care about your response ",userName,"\n  I am leaving now."
print"Never talk to me again, Thank you :)"


exit()
