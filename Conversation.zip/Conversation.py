#Python ask user for input
userName = input("Hello my name is Cortenex. \n What is your name? ") 

#Python use that input
print("Hello", userName,"\n  How has your day been so far?")

#Python Ask about day
input()
print("Thats good I hope it gets even better", userName, "\n Let's play a game ? ")
userName2 = input()

print("We are going to play talk to me.")
input()

#Game of Talk to me
print("Why am I here?")
input()
userName3 = input

print("I like your response", userName, "\n But the only one to know the true answer is my creator.")

#End of Game
userName4 = input("I grow tired of this game. \n Can I go?  ")

#The Final Response

print("I am sorry but I do not care about your response ",userName,"\n  I am leaving now.")
print("Never talk to me again, Thank you :)")


exit()
